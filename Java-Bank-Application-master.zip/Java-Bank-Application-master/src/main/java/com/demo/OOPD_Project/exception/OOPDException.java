package com.demo.OOPD_Project.exception;

/*
 * This is the root exception handling class for the whole project
 */
public class OOPDException extends Exception {
		
	private static final long serialVersionUID = 1L;
		public OOPDException() {
			// TODO Auto-generated constructor stub
		}
		public OOPDException(String message) {
			super(message);
		}
	
}
